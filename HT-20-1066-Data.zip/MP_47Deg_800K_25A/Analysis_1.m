%% Average Temperatures

WLIC825Mid=dlmread('Average_Temperature_Middle_Layers.sh', ' ', 2, 0);
WLIC825Top=dlmread('Average_Temperature_Top_Layers.sh', ' ', 2, 0);
WLIC825Wat=dlmread('Average_Temperature_Water.sh', ' ', 2, 0);

Time=WLIC825Mid(:,1)./1000;


%Average Temperatures Figure
figure
scatter(Time, WLIC825Mid(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WLIC825Top(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WLIC825Wat(:,2), 5, 'red', 'filled')
title('LJHL 800K 25A Average Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'Middle Layer Temperature', 'Top Layer Temperature', 'Water Temperature'}, 'Location', 'southeast')





%% Density Gradient
WLIC825L1=dlmread('L1WatNum.sh', ' ', 2, 0);
WLIC825L2=dlmread('L2WatNum.sh', ' ', 2, 0);
WLIC825L3=dlmread('L3WatNum.sh', ' ', 2, 0);
WLIC825L4=dlmread('L4WatNum.sh', ' ', 2, 0);
WLIC825L5=dlmread('L5WatNum.sh', ' ', 2, 0);

%Density Figure
figure
scatter(Time, WLIC825L1(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WLIC825L2(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WLIC825L3(:,2), 5, 'red', 'filled')
hold on
scatter(Time, WLIC825L4(:,2), 5, 'black', 'filled')
hold on
scatter(Time, WLIC825L5(:,2), 5, 'magenta', 'filled')

xlim([1500 1800])
xlabel('Time (ps)','FontSize', 18, 'FontName', 'Times New Roman')
ylabel('Number of Water Molecules','FontSize', 18, 'FontName', 'Times New Roman')
legend({'0nm-4nm', '4nm-8nm', '8nm-12nm', '12nm-16nm', '16nm-20nm'}, 'Location', 'southeastoutside','FontSize', 18, 'FontName', 'Times New Roman')
set(gca,'FontSize', 18)
set(gca, 'TickLength', [0.1,0.1]);
title('                 LJHL 800K Number Density Gradient','FontSize', 16, 'FontName', 'Times New Roman')

%% Temperature Gradient

% WatGrad=dlmread('Water_Info.sh', ' ',[2186876 0 2188812 4]); %1130ps
% 
% OrdWatGrad=sortrows(WatGrad,5);
% L1=OrdWatGrad(:,5)>=22.967 & OrdWatGrad(:,5)<=31.267;
% MeanL1=mean(OrdWatGrad(L1,2));
% 
% OrdWatGrad=sortrows(WatGrad,5);
% L2=OrdWatGrad(:,5)>=31.267 & OrdWatGrad(:,5)<=39.567;
% MeanL2=mean(OrdWatGrad(L2,2));
% 
% OrdWatGrad=sortrows(WatGrad,5);
% L3=OrdWatGrad(:,5)>=39.567 & OrdWatGrad(:,5)<=47.867;
% MeanL3=mean(OrdWatGrad(L3,2));

%% Max Temperature
MaxWat=max(WLIC825Wat);

%% Energy
KE=dlmread('KEWater.sh', ' ', 2, 0);
PE=dlmread('PEWater.sh', ' ', 2, 0);

TE1_fs=KE+PE;



%Energy Figure
figure
scatter(Time, TE1_fs(:,2), 5, 'blue', 'filled')

title('1fs Timestep')
xlabel('Time (ps)')
ylabel('Energy (eV)')

