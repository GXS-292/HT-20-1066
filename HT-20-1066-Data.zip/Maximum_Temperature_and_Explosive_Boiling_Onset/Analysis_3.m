%% Maximum Temperature Plot

% Data
pt1=[800 539.248];
pt2=[800 609.867];
pt3=[800 614.148];

pt4=[1000 551.13];
pt5=[1000 641.634];
pt6=[1000 662.182];

pt7=[1000 546.808];
pt8=[1000 616.144];
pt9=[1000 626.365];



figure
%Legend



h=zeros(6,1);
h(1)=scatter(h,h, 50, 'blue', 'o');
hold on
h(2)=scatter(h,h, 50, 'blue', 'd');
hold on
h(3)=scatter(h,h, 50, 'blue','^');
hold on
h(4)=scatter(h,h, 50, 'blue', 'filled', 'o');
hold on
h(5)=scatter(h,h, 50, 'blue', 'filled', 'd');
hold on
h(6)=scatter(h,h, 50, 'blue', 'filled', '^');
hold on


%Plot

scatter(pt1(1,1),pt1(1,2), 50, 'blue', 'filled', 'o')
hold on
scatter(pt2(1,1),pt2(1,2), 50, 'blue', 'filled', 'd')
hold on
scatter(pt3(1,1),pt3(1,2), 50, 'blue', 'filled', '^')

hold on

scatter(pt4(1,1),pt4(1,2), 50, 'blue', 'o')
hold on
scatter(pt5(1,1),pt5(1,2), 50, 'blue', 'd')
hold on
scatter(pt6(1,1),pt6(1,2), 50, 'blue', '^')

hold on

scatter(pt7(1,1),pt7(1,2), 50, 'blue', 'filled', 'o')
hold on
scatter(pt8(1,1),pt8(1,2), 50, 'blue', 'filled', 'd')
hold on
scatter(pt9(1,1),pt9(1,2), 50, 'blue', 'filled', '^')


xlim([750 1050])
xlabel('Substrate Temperature (K)','FontSize', 18, 'FontName', 'Times New Roman')
ylabel('Water Temperature (K)','FontSize', 18, 'FontName', 'Times New Roman')
legend({'LJHB 1.6nm', 'LJHL 1.6nm', 'MP 1.6nm', 'LJHB 2.5nm', 'LJHL 2.5nm', 'MP 2.5nm'}, 'Location', 'south','FontSize', 18, 'FontName', 'Times New Roman')
set(gca, 'FontSize', 16)
set(gca, 'TickLength', [0.03,0.03]);
title('Maximum Water Temperature','FontSize', 16, 'FontName', 'Times New Roman')
%% Onset of explosive boiling plot

% Data
pt1=[110 2111];
pt2=[47 1265];
pt3=[11 1383];

pt4=[110 2011];
pt5=[47 1194];
pt6=[11 1231];

pt7=[110 1915];
pt8=[47 1204];
pt9=[11 1269];

c1=[110 2111;47 1265;11 1383];
c2=[110 2011;47 1194;11 1231];
c3=[110 1915;47 1204;11 1269];

figure
%Legend



h=zeros(3,1);
h(1)=scatter(h,h, 50, 'blue', 'filled', 'o');
hold on
h(2)=scatter(h,h, 50, 'red', 'filled','d');
hold on
h(3)=scatter(h,h, 50, 'blue', 'filled', 'd');
hold on




%Plot


plot(c1(:,1),c1(:,2), 'blue', 'Marker', 'o', 'MarkerFaceColor', 'blue', 'LineWidth', 1.0)
hold on
plot(c2(:,1),c2(:,2), 'red', 'Marker', 'd', 'MarkerFaceColor', 'red', 'LineWidth', 1.0)
hold on
plot(c3(:,1),c3(:,2), 'blue', 'Marker', 'd', 'MarkerFaceColor', 'blue', 'LineWidth', 1.0)


% scatter(pt1(1,1),pt1(1,2), 30, 'blue', 'filled', 'o')
% hold on
% scatter(pt2(1,1),pt2(1,2), 30, 'blue', 'filled', 'o')
% hold on
% scatter(pt3(1,1),pt3(1,2), 30, 'blue', 'filled', 'o')
% 
% hold on
% 
% scatter(pt4(1,1),pt4(1,2), 30, 'red', 'filled', 's')
% hold on
% scatter(pt5(1,1),pt5(1,2), 30, 'red', 'filled', 's')
% hold on
% scatter(pt6(1,1),pt6(1,2), 30, 'red', 'filled', 's')
% 
% hold on
% 
% scatter(pt7(1,1),pt7(1,2), 30, 'blue', 'filled', 's')
% hold on
% scatter(pt8(1,1),pt8(1,2), 30, 'blue', 'filled', 's')
% hold on
% scatter(pt9(1,1),pt9(1,2), 30, 'blue', 'filled', 's')


xlim([0 120])
ylim([1100 2200])
xlabel(['Contact Angle (' char(176) ')'],'FontSize', 18, 'FontName', 'Times New Roman')
ylabel('Time (ps)','FontSize', 18, 'FontName', 'Times New Roman')
legend({'2.5nm 800K', '1.6nm 1000K', '2.5nm 1000K'}, 'Location', 'northwest','FontSize', 18, 'FontName', 'Times New Roman')
set(gca, 'FontSize', 16)
set(gca, 'TickLength', [0.03,0.03]);
title('Time to Onset of Explosive Boiling','FontSize', 16, 'FontName', 'Times New Roman')


%% Morse Increasing Hydrophobicity plot

c1=[45 1585;11 1383];
c2=[45 1340;11 1231];
c3=[45 1373;11 1269];


%Plot
plot(c1(:,1),c1(:,2), 'blue', 'Marker', 'o', 'MarkerFaceColor', 'blue', 'LineWidth', 1.0)
hold on
plot(c2(:,1),c2(:,2), 'red', 'Marker', 'd', 'MarkerFaceColor', 'red', 'LineWidth', 1.0)
hold on
plot(c3(:,1),c3(:,2), 'blue', 'Marker', 'd', 'MarkerFaceColor', 'blue', 'LineWidth', 1.0)


xlim([0 60])
ylim([1000 1600])
xlabel(['Contact Angle (' char(176) ')'],'FontSize', 18, 'FontName', 'Times New Roman')
ylabel('Time (ps)','FontSize', 18, 'FontName', 'Times New Roman')
legend({'2.5nm 800K', '1.6nm 1000K', '2.5nm 1000K'}, 'Location', 'south','FontSize', 18, 'FontName', 'Times New Roman')
set(gca, 'FontSize', 16)
set(gca, 'TickLength', [0.03,0.03]);
title('Time to Onset of Explosive Boiling (Morse Only)','FontSize', 16, 'FontName', 'Times New Roman')
