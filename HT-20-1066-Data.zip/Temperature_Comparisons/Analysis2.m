%% 400K Data

%7A Thickness
load('Analysis1_400K_7A_BIC.mat')
load('Analysis1_400K_7A_BM.mat')
load('Analysis1_400K_7A_LIC.mat')

%16A Thickness
load('Analysis1_400K_16A_BIC.mat')
load('Analysis1_400K_16A_BM.mat')
load('Analysis1_400K_16A_LIC.mat')

%25A Thickness
load('Analysis1_400K_25A_BIC.mat')
load('Analysis1_400K_25A_BM.mat')
load('Analysis1_400K_25A_LIC.mat')

%Average Temperatures Figure
figure
scatter(Time, WBIC47Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WBIC416Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WBIC425Wat(:,2), 5, 'red', 'filled')
title('Wang Hydrophobic 400K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')


figure
scatter(Time, WLIC47Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WLIC416Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WLIC425Wat(:,2), 5, 'red', 'filled')
title('Wang Hydrophilic 400K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')

figure
scatter(Time, BM47Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, BM416Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, BM425Wat(:,2), 5, 'red', 'filled')
title('Berg Morse 400K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')

%% 600K data

%7A Thickness
load('Analysis1_600K_7A_Bic.mat')
load('Analysis1_600K_7A_BM.mat')
load('Analysis1_600K_7A_Lic.mat')

%16A Thickness
load('Analysis1_600K_16A_Bic.mat')
load('Analysis1_600K_16A_BM.mat')
load('Analysis1_600K_16A_Lic.mat')

%25A Thickness
load('Analysis1_600K_25A_Bic.mat')
load('Analysis1_600K_25A_BM.mat')
load('Analysis1_600K_25A_Lic.mat')

%Average Temperatures Figure
figure
scatter(Time, WBIC67Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WBIC616Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WBIC625Wat(:,2), 5, 'red', 'filled')
title('Wang Hydrophobic 600K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')


figure
scatter(Time, WLIC67Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WLIC616Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WLIC625Wat(:,2), 5, 'red', 'filled')
title('Wang Hydrophilic 600K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')

figure
scatter(Time, BM67Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, BM616Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, BM625Wat(:,2), 5, 'red', 'filled')
title('Berg Morse 600K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')

%% 800K Data

%7A Thickness
load('Analysis1_800K_7A_Bic.mat')
load('Analysis1_800K_7A_BM.mat')
load('Analysis1_800K_7A_Lic.mat')

%16A Thickness
load('Analysis1_800K_16A_Bic.mat')
load('Analysis1_800K_16A_BM.mat')
load('Analysis1_800K_16A_Lic.mat')

%25A Thickness
load('Analysis1_800K_25A_Bic.mat')
load('Analysis1_800K_25A_BM.mat')
load('Analysis1_800K_25A_Lic.mat')

%Average Temperatures Figure
figure
scatter(Time, WBIC87Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WBIC816Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WBIC825Wat(:,2), 5, 'red', 'filled')
xlabel('Time (ps)','FontSize', 18, 'FontName', 'Times New Roman')
ylabel('Temperature (K)','FontSize', 18, 'FontName', 'Times New Roman')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast','FontSize', 18, 'FontName', 'Times New Roman')
set(gca, 'FontSize', 16);
set(gca, 'TickLength', [0.03,0.03]);
title('LJHB 800K Water Temperatures','FontSize', 16, 'FontName', 'Times New Roman')


figure
scatter(Time, WLIC87Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WLIC816Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WLIC825Wat(:,2), 5, 'red', 'filled')
xlabel('Time (ps)','FontSize', 18, 'FontName', 'Times New Roman')
ylabel('Temperature (K)','FontSize', 18, 'FontName', 'Times New Roman')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast','FontSize', 18, 'FontName', 'Times New Roman')
set(gca, 'FontSize', 16);
set(gca, 'TickLength', [0.03,0.03]);
title('LJHL 800K Water Temperatures','FontSize', 16, 'FontName', 'Times New Roman')

figure
scatter(Time, BM87Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, BM816Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, BM825Wat(:,2), 5, 'red', 'filled')
xlabel('Time (ps)','FontSize', 18, 'FontName', 'Times New Roman')
ylabel('Temperature (K)','FontSize', 18, 'FontName', 'Times New Roman')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast','FontSize', 18, 'FontName', 'Times New Roman')
set(gca, 'FontSize', 16);
set(gca, 'TickLength', [0.03,0.03]);
title('MP 800K Water Temperatures','FontSize', 16, 'FontName', 'Times New Roman')

%% 1000K Data

%7A Thickness
load('Analysis1_1000K_7A_Bic.mat')
load('Analysis1_1000K_7A_BM.mat')
load('Analysis1_1000K_7A_Lic.mat')

%16A Thickness
load('Analysis1_1000K_16A_Bic.mat')
load('Analysis1_1000K_16A_BM.mat')
load('Analysis1_1000K_16A_Lic.mat')

%25A Thickness
load('Analysis1_1000K_25A_Bic.mat')
load('Analysis1_1000K_25A_BM.mat')
load('Analysis1_1000K_25A_Lic.mat')

%Average Temperatures Figure
figure
scatter(Time, WBIC17Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WBIC116Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WBIC125Wat(:,2), 5, 'red', 'filled')
title('Wang Hydrophobic 1000K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')


figure
scatter(Time, WLIC17Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, WLIC116Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, WLIC125Wat(:,2), 5, 'red', 'filled')
title('Wang Hydrophilic 1000K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')

figure
scatter(Time, BM17Wat(:,2), 5, 'blue', 'filled')
hold on
scatter(Time, BM116Wat(:,2), 5, 'green', 'filled')
hold on
scatter(Time, BM125Wat(:,2), 5, 'red', 'filled')
title('Berg Morse 1000K Water Temperatures')
xlabel('Time (ps)')
ylabel('Temperature (K)')
legend({'0.7nm', '1.6nm', '2.5nm'},'Location', 'southeast')














