###Berg_Morse_1000K_25A###

clear
echo both			#Output code to both log file and terminal screen
units	metal		#Units are of metal style (distance=Angstrom, time=picosecond, energy=eV, temperature=K, pressure=bars)
atom_style full	#Atoms have charge as well a molecular attributes
boundary p p f		#non-periodic and fixed boundary condition in the z-direction, periodic boundary conditions in the x and y directions


###Creating Gold Substrate###
lattice fcc 4.08 orient x 1 -1 0 orient y 1 1 -2 orient z 1 1 1	#Create a lattice constant of 4.08 Angstroms FCC style to be applied to Gold (111) face in the z direction

region 1substrate block -1 7 0 6.5 0.25 0.5 units lattice 		#Create a region called 1substrate that contains the lattice atoms on the bottom layer
region 2substrate block -1 7 0 6.5 0.5 1.75 units lattice		#Create a region called 2substrate that contains the lattice atoms in the middle 4 layers
region 3substrate block -1 7 0 6.5 2.0 3.25 units lattice	 	#Create a region called 3substrate that contains the lattice atoms in the top 4 layers 
region domain block 0 40 -1 39.2 0 222.967 units box			#Create a region called domain for the simulation box to exist

create_box 5 domain bond/types 1 angle/types 1	extra/bond/per/atom 2 extra/angle/per/atom 1	#Create a simulation box in the region called domain that has 5 types of atoms,
																								#1 bond type, 1 angle type, allows for 2 bonds per atom 
																								#and allows for 1 angle per atom

create_atoms 3 region 1substrate	#create type 3 atoms in the region called 1substrate
create_atoms 4 region 2substrate	#create type 4 atoms in the region called 2substrate
create_atoms 5 region 3substrate	#create type 5 atoms in the region called 3substrate

###Regions Density gradient plots###
region L1 block EDGE EDGE EDGE EDGE 22.967 62.967 units box	#0-40nm from surface
region L2 block EDGE EDGE EDGE EDGE 62.967 102.967 units box	#40-80nm from surface
region L3 block EDGE EDGE EDGE EDGE 102.967 142.967 units box #80-120nm from surface
region L4 block EDGE EDGE EDGE EDGE 142.967 182.967 units box	#120-160nm from surface
region L5 block EDGE EDGE EDGE EDGE 182.967 222.967 units box #160-200nm from surface

###Setting Mass of the atoms in the simulation###
mass 1 1.008	#Set mass of type 1 atoms (Hydrogen)
mass 2 15.9994	#Set mass of type 2 atoms (Oxygen)
mass 3 196.7	#Set the mass of type 3 atoms (Gold atoms in the bottom layer)
mass 4 196.7	#Set the mass of type 4 atoms (Gold atoms in the middle 4 layers)
mass 5 196.7	#Set the mass of type 5 atoms (Gold atoms in the top 4 layers)

set type 3*5 mol 0

###Puting Water into the Simulation domian###
read_data Water_25A.SPCE add append shift 0 0 5.5	#Read the data file called water.SPCE to add water molecules to the simultion


###Setting Charge of the Atoms in the Simulation###
set type 1 charge 0.4238		#Set the charge of type 1 atoms (hydrogen)
set type 2 charge -0.8476	#Set the charge of type 2 atoms (oxygen)
set type 3*5 charge 0.0		#Set the charge of type 3, type 4 and type 5 atoms (gold)



###Setting Interaction Parameters###
pair_style hybrid eam/alloy lj/cut/coul/long 10.0 morse 12 # Allow for multiple pair styles to be used in general and per interaction pair

#Pair style eam/alloy will be used for the Gold to Gold atom interactions
#Pair style lj/cut/coul/long uses a standard 12-6 lennard-jones interaction potential with a cutoff of 10 angstroms and no cutoff for the electrostatic term


###Gold Interaction###

pair_coeff * * eam/alloy Au.eam.alloy NULL NULL Au Au Au #Maps the atom types 3, 4 and 5 to the Au elemt in the setfl file

###Water Interaction###

pair_coeff 1 1 lj/cut/coul/long 0.0 0.0				#Hydrogen-Hydrogen
pair_coeff 1 2 lj/cut/coul/long	0.0 0.0				#Hydrogen-Oxygen        
pair_coeff 2 2 lj/cut/coul/long	0.0067345 3.166 	#Oxygen-Oxygen 
	


###Gold-water Interaction###

pair_coeff 1 3*5 morse 0.00049746 1.41 4.14 			#Hydrogen-Gold
pair_coeff 2 3*5 morse 0.01156662 0.905 4.20 	#Oxygen-Gold

###Long-range Columbic Solver###
kspace_style pppm 1.0e-5 
kspace_modify slab 3.0

###Bond Parameters###
bond_style harmonic 	#Harmonic Bond Style (for SPC/E water)
bond_coeff 1 1000 1.0	#Bond type 1 has an equilibrium distance of 1.0 angstrom

###Angle Parameters###
angle_style harmonic 	#Harmonic Angle Style (for SPC/E Water)
angle_coeff 1 100 109.47	#Angle type 1 has an angle coefficient of 109.47 degrees 


###Putting Atoms into Groups###
group	Hydrogen type 1				#Create a group called hydrogen and fill it with type 1 atoms
group	Oxygen   type 2				#Create a group called oxygen and fill it with type 2 atoms
group	BL	 type 3					#Create a group called BL (Bottom Layer) and fill it with type 4 atoms
group   MLs	 type 4					#Create a group called MLs (Middle Layers) and fill it with type 5 atoms
group   TLs  type 5					#Create a group called TLs (Top Layers) and fill it with type 3 atoms
group   Water union Hydrogen Oxygen	#Create a group called water that is the union of the groups hydrogen and oxygen
group   Gold union MLs TLs 			#Create a group called gold that is the union of the groups MLs and TLs

###System Initilizations###
timestep 0.001							#Have a simulation time step of 0.001 picoseconds (or 1 femtosecond)
neighbor 2.0 bin						#Have a skin distance of 2 Angstroms and sort the atoms by binning
neigh_modify every 1 delay 0 check yes	#Build neighbor list every timestep 
										#do not delay by any timesteps and check if an atom has 
										#moved more than half the skin distance

fix Wall Water wall/reflect zhi EDGE	#Create a fix called wall that effects all atoms and will reflect atoms that attempt to move through
										#the top of the simulation domian (for this to work the dimension must be non perodic)

###Calculate Overall Temperature of Gold and Water###										
compute TMLs MLs temp
fix TempMidGold MLs ave/time 100 10 1000 c_TMLs file Average_Temperature_Middle_Layers.sh

compute TTLs TLs temp
fix TempTopGold TLs ave/time 100 10 1000 c_TTLs file Average_Temperature_Top_Layers.sh

compute TWater Water temp
fix TempWater Water ave/time 100 10 1000 c_TWater file Average_Temperature_Water.sh	
					

###Temperature Profile###
compute Water_Ms Water chunk/atom molecule
compute Water_Ms_Temp Water temp/chunk Water_Ms temp adof 0 cdof 6
compute Water_Ms_Location Water com/chunk Water_Ms
fix Water_Ms_Info Water ave/time 100 10 1000 c_Water_Ms_Temp[1] c_Water_Ms_Location[*] file Water_Info.sh mode vector

###Water Energy Monitor###
compute Water_KE Water ke/atom
compute Water_PE Water pe/atom
compute Water_Kinetic Water reduce sum c_Water_KE
compute Water_Potential Water reduce sum c_Water_PE
fix WKE Water ave/time 100 10 1000 c_Water_Kinetic file KEWater.sh
fix WPE	Water ave/time 100 10 1000 c_Water_Potential file PEWater.sh					

###Density Profile###
variable L1_Water_Number equal count(Water,L1)/3	#Count the number of Water molecules in the L1 region
fix L1_WN Water ave/time 100 10 1000 v_L1_Water_Number file L1WatNum.sh

variable L2_Water_Number equal count(Water,L2)/3
fix L2_WN Water ave/time 100 10 1000 v_L2_Water_Number file L2WatNum.sh

variable L3_Water_Number equal count(Water,L3)/3 
fix L3_WN Water ave/time 100 10 1000 v_L3_Water_Number file L3WatNum.sh

variable L4_Water_Number equal count(Water,L4)/3
fix L4_WN Water ave/time 100 10 1000 v_L4_Water_Number file L4WatNum.sh

variable L5_Water_Number equal count(Water,L5)/3 
fix L5_WN Water ave/time 100 10 1000 v_L5_Water_Number file L5WatNum.sh								

###Final Output Initializations###
thermo_modify lost ignore lost/bond ignore flush yes 	#Make thermodynamic output to file current
thermo 1000												#Print thermodynamic information every 1000 timesteps
atom_modify sort 1 2									#Sort atoms spacially every timestep for a bin size of 2 Angstrom
dump test all atom 1000 Berg_Morse_1000K_25A.lammpstrj				#Create a dump command called test that affects all groups 
						

###Initialize Temperature of Gold and Water
velocity Gold create 50 123456 loop local	#Effect the kinetic temperature of the atoms in the Gold group 
											#set the temperature to 298K initially (123456 is a random seed number)

velocity Water create 50 124568 loop local #Effect the kinetic temperature of the atoms in the water group
											#set the temperature to 298K initially (124568 is a random seed number)

run 0							#Ensuring all degrees of freedom are properly acconted for

velocity Gold scale 50			#Explicitly scale the temperature of the gold atoms to 298K
velocity Water scale 50		#Explicitly scale the temperature of the water molecules to 298K

fix 1 Water nvt temp 50 298 0.01 	#create a fix called 1 that effects the atoms in the water group with a canonical ensemble thermostat
									#have the temperature start at 298K and end at 298K with a damping parameter of 1 picosecond 

fix 2 Gold nvt temp 50 298 0.01 	
								

fix constrain Water rattle 1.0e-5 100 0 b 1 a 1	#Create a fix called constrain that effects the atoms in the water group that, employs the SHAKE algorithm
												#has a solution tolerance of 1e-4, has a value of 100 as the maximum number of iterations to find a solution,
												#does not print the SHAKE statistics at any time step, utilizes one bond type and one angle type



run 100000  #Melting Run for 100ps

unfix 1
unfix 2
unfix constrain

fix 1 Water nve 

fix 2 MLs nvt temp 298 298 0.01 	

fix 3 TLs nve								

fix constrain Water rattle 1.0e-5 100 0 b 1 a 1	#Create a fix called constrain that effects the atoms in the water group that, employs the SHAKE algorithm
												#has a solution tolerance of 1e-4, has a value of 100 as the maximum number of iterations to find a solution,
												#does not print the SHAKE statistics at any time step, utilizes one bond type and one angle type



run 1000000  #Equilibration Run for 1000ps



###################################################################Temperature Ramp#############################################################################


unfix 1	#Undo the fix called 1
unfix 2	
unfix 3
unfix constrain	

fix 1 Water nve 

fix 2 MLs nvt temp 298 1000 0.01

fix 3 TLs nve

fix constrain Water rattle 1.0e-5 100 0 b 1 a 1	
	
run 3000	#Temperature ramp in 3ps  

######################################################################Production Run##############################################################################

unfix 1   
unfix 2
unfix 3
unfix constrain

fix 1 Water nve

fix 2 MLs nvt temp 1000 1000 0.01

fix 3 TLs nve

fix constrain Water rattle 1.0e-5 100 0 b 1 a 1	

run 2500000	#Production run for 2500ps
