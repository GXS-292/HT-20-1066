#!/bin/bash
module load xl_r
module load spectrum-mpi
module load cuda/10.1

module load spectrum-mpi
module load cuda/10.1

if [ "x$SLURM_NPROCS" = "x" ] 
then
  if [ "x$SLURM_NTASKS_PER_NODE" = "x" ] 
  then
    SLURM_NTASKS_PER_NODE=1
  fi
  SLURM_NPROCS=`expr $SLURM_JOB_NUM_NODES \* $SLURM_NTASKS_PER_NODE`
fi
dirpath="/gpfs/u/home/MDSP/MDSPmlcm/lammps-7Aug19/src"
srun hostname -s > /tmp/hosts.$SLURM_JOB_ID
mpirun -hostfile /tmp/hosts.$SLURM_JOB_ID ${dirpath}/lmp_mpi -in Wang_Hydrophilic_800K_25A.sh
rm /tmp/hosts.$SLURM_JOB_ID
