###Wang_Hydrophobic_CA###

clear
echo both			#Output code to both log file and terminal screen
units	metal		#Units are of metal style (distance=Angstrom, time=picosecond, energy=eV, temperature=K, pressure=bars)
atom_style full	#Atoms have charge as well a molecular attributes
boundary p p p		#non-periodic and fixed boundary condition in the z-direction, periodic boundary conditions in the x and y directions


###Creating Gold Substrate###
lattice fcc 4.08 orient x 1 -1 0 orient y 1 1 -2 orient z 1 1 1	#Create a lattice constant of 4.08 Angstroms FCC style to be applied to Gold (111) face in the z direction

region 1substrate block 0 28 0 28 0.25 0.5 units lattice 		#Create a region called 1substrate that contains the lattice atoms on the bottom layer
region 2substrate block 0 28 0 28 0.5 1.75 units lattice		#Create a region called 2substrate that contains the lattice atoms in the middle 4 layers
region 3substrate block 0 28 0 28 2.0 3.25 units lattice	 	#Create a region called 3substrate that contains the lattice atoms in the top 4 layers 
region domain block -1 160 -1 160 -1 160 units box			#Create a region called domain for the simulation box to exist

create_box 5 domain bond/types 1 angle/types 1	extra/bond/per/atom 2 extra/angle/per/atom 1	#Create a simulation box in the region called domain that has 5 types of atoms,
																								#1 bond type, 1 angle type, allows for 2 bonds per atom 
																								#and allows for 1 angle per atom

create_atoms 3 region 1substrate	#create type 3 atoms in the region called 1substrate
create_atoms 4 region 2substrate	#create type 4 atoms in the region called 2substrate
create_atoms 5 region 3substrate	#create type 5 atoms in the region called 3substrate



###Setting Mass of the atoms in the simulation###
mass 1 1.008	#Set mass of type 1 atoms (Hydrogen)
mass 2 15.9994	#Set mass of type 2 atoms (Oxygen)
mass 3 196.7	#Set the mass of type 3 atoms (Gold atoms in the bottom layer)
mass 4 196.7	#Set the mass of type 4 atoms (Gold atoms in the middle 4 layers)
mass 5 196.7	#Set the mass of type 5 atoms (Gold atoms in the top 4 layers)

set type 3*5 mol 0

###Puting Water into the Simulation domian###
read_data Water_25A.SPCE add append shift 60 60 5.5	#Read the data file called water.SPCE to add water molecules to the simultion

###Setting Charge of the Atoms in the Simulation###
set type 1 charge 0.4238		#Set the charge of type 1 atoms (hydrogen)
set type 2 charge -0.8476	#Set the charge of type 2 atoms (oxygen)
set type 3*5 charge 0.0		#Set the charge of type 3, type 4 and type 5 atoms (gold)



###Setting Interaction Parameters###
pair_style hybrid eam/alloy lj/cut/coul/long 10.0 # Allow for multiple pair styles to be used in general and per interaction pair

#Pair style eam/alloy will be used for the Gold to Gold atom interactions
#Pair style lj/cut/coul/long uses a standard 12-6 lennard-jones interaction potential with a cutoff of 10 angstroms and no cutoff for the electrostatic term


###Gold Interaction###

pair_coeff * * eam/alloy Au.eam.alloy NULL NULL Au Au Au #Maps the atom types 3, 4 and 5 to the Au elemt in the setfl file

###Water Interaction###

pair_coeff 1 1 lj/cut/coul/long 0.0 0.0				#Hydrogen-Hydrogen
pair_coeff 1 2 lj/cut/coul/long	0.0 0.0				#Hydrogen-Oxygen        
pair_coeff 2 2 lj/cut/coul/long	0.0067345 3.166 	#Oxygen-Oxygen 
	


###Gold-water Interaction###

pair_coeff 1 3*5 lj/cut/coul/long 0.0 0.0 			#Hydrogen-Gold
pair_coeff 2 3*5 lj/cut/coul/long 0.0082 2.8675 	#Oxygen-Gold

###Long-range Columbic Solver###
kspace_style pppm 1.0e-5 
#kspace_modify slab 3.0

###Bond Parameters###
bond_style harmonic 	#Harmonic Bond Style (for SPC/E water)
bond_coeff 1 1000 1.0	#Bond type 1 has an equilibrium distance of 1.0 angstrom

###Angle Parameters###
angle_style harmonic 	#Harmonic Angle Style (for SPC/E Water)
angle_coeff 1 100 109.47	#Angle type 1 has an angle coefficient of 109.47 degrees 


###Putting Atoms into Groups###
group	Hydrogen type 1				#Create a group called hydrogen and fill it with type 1 atoms
group	Oxygen   type 2				#Create a group called oxygen and fill it with type 2 atoms
group	BL	 type 3					#Create a group called BL (Bottom Layer) and fill it with type 4 atoms
group   MLs	 type 4					#Create a group called MLs (Middle Layers) and fill it with type 5 atoms
group   TLs  type 5					#Create a group called TLs (Top Layers) and fill it with type 3 atoms
group   Water union Hydrogen Oxygen	#Create a group called water that is the union of the groups hydrogen and oxygen
group   Gold union MLs TLs 			#Create a group called gold that is the union of the groups MLs and TLs

###System Initilizations###
timestep 0.001							#Have a simulation time step of 0.001 picoseconds (or 1 femtosecond)
neighbor 2.0 bin						#Have a skin distance of 2 Angstroms and sort the atoms by binning
neigh_modify every 1 delay 0 check yes	#Build neighbor list every timestep 
										#do not delay by any timesteps and check if an atom has 
										#moved more than half the skin distance

#fix Wall Water wall/reflect zhi EDGE	#Create a fix called wall that effects all atoms and will reflect atoms that attempt to move through
										#the top of the simulation domian (for this to work the dimension must be non perodic)

###Calculate Overall Temperature of Gold and Water###										
compute TMLs MLs temp
fix TempMidGold MLs ave/time 100 10 1000 c_TMLs file Average_Temperature_Middle_Layers.sh

compute TTLs TLs temp
fix TempTopGold TLs ave/time 100 10 1000 c_TTLs file Average_Temperature_Top_Layers.sh

compute TWater Water temp
fix TempWater Water ave/time 100 10 1000 c_TWater file Average_Temperature_Water.sh	
															


###Final Output Initializations###
thermo_modify lost ignore lost/bond ignore flush yes 	#Make thermodynamic output to file current
thermo 1000												#Print thermodynamic information every 1000 timesteps
atom_modify sort 1 2									#Sort atoms spacially every timestep for a bin size of 2 Angstrom
dump test all atom 1000 Wang_Hydrophobic_400K_CA.lammpstrj				#Create a dump command called test that affects all groups 
						

###Initialize Temperature of Gold and Water
velocity Gold create 50 123456 loop local	#Effect the kinetic temperature of the atoms in the Gold group 
											#set the temperature to 298K initially (123456 is a random seed number)

velocity Water create 50 124568 loop local #Effect the kinetic temperature of the atoms in the water group
											#set the temperature to 298K initially (124568 is a random seed number)

run 0							#Ensuring all degrees of freedom are properly acconted for

velocity Gold scale 50			#Explicitly scale the temperature of the gold atoms to 298K
velocity Water scale 50		#Explicitly scale the temperature of the water molecules to 298K

fix 1 Water nvt temp 50 298 0.01 	#create a fix called 1 that effects the atoms in the water group with a canonical ensemble thermostat
									#have the temperature start at 298K and end at 298K with a damping parameter of 1 picosecond 

fix 2 Gold nvt temp 50 298 0.01 	
								

fix constrain Water rattle 1.0e-5 100 0 b 1 a 1	#Create a fix called constrain that effects the atoms in the water group that, employs the SHAKE algorithm
												#has a solution tolerance of 1e-4, has a value of 100 as the maximum number of iterations to find a solution,
												#does not print the SHAKE statistics at any time step, utilizes one bond type and one angle type


run 100000  #Melting for 100ps

###################################################################Temperature Ramp#############################################################################


unfix 1	#Undo the fix called 1
unfix 2	
unfix constrain	

fix 1 Water nvt temp 298 298 0.01

fix 2 Gold nvt temp 298 298 0.01


fix constrain Water rattle 1.0e-5 100 0 b 1 a 1	
	
run 200000	#Equilibration for 200ps 

######################################################################Production Run##############################################################################

		
	





